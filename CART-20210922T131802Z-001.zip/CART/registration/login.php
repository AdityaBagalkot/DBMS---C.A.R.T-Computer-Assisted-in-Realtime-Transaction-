<?php 
    session_start();     
    include('connection.php');  
    $username = $_POST['user'];  
    $password = $_POST['pass'];  

        $username = stripcslashes($username);  
        $password = stripcslashes($password);  
        $username = mysqli_real_escape_string($con, $username);  
        $password = mysqli_real_escape_string($con, $password);  
      
        $sql = "SELECT * from users where username = '$username' and password = '$password'";  
        $result = mysqli_query($con, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $co = mysqli_num_rows($result); 
          
        if($co == 1){  
            $_SESSION['username'] = $username;
            header('location: index2.php');
        }  
        else{  
            $_SESSION['message1'] = "Invalid username or password";
            header("location:no.php");
        }     
?>  