<?php
include 'connection.php';
error_reporting(0);
//$pid=$_GET['pid'];
$res=mysqli_query($con,"SELECT * FROM shoprite Where prod_ID='1415603'");
$row=mysqli_fetch_array($res);
    $id=$row['pid'];
    $pn=$row['prod_name'];
    $st=$row['stock'];
    $sid=$row['shop_id'];
    $ano=$row['aisle_no']; 
    $des=$row['describ'];
    $img=$row['img'];
    $off=$row['offer'];
    $price=$row['price'];
?>

<!DOCTYPE html>
<head>
  <link rel="stylesheet" type="text/css" href="dup.css">
</head>
<body>
    <div class="login">
        <form name="form1" action="" method="post" enctype="multipart/form-data">
            <img src="<?php echo "$img" ;?>" height=100 width=100><br>
            Product Name<input type="text" class="lbox" name="pname" value="<?php echo $pn;?>" /><br>
            Stock<input type="text"class="lbox" name="stock" value="<?php echo $st;?>" /><br>
            Shop ID<br><input type="text" class="lbox" name="shopid" value="<?php echo $sid ;?>" /><br>
            Aisle_no<br><input type="text" class="lbox" name="aisleno" value="<?php echo $ano ;?>" /><br>
            Description<input type="text" class="lbox" name="desc" value="<?php echo $des ;?>" /><br>
            Offer<br><input type="text" class="lbox" name="offer" value="<?php echo $off ;?>" /><br>
            Price<br><input type="text" class="lbox" name="pri" value="<?php echo $price ;?>" /><br>
           <button name="submit"> submit </button>
      </div>


</body>
</html> 
<?php if(isset($_POST['submit'])){
   $name=$_POST['pname'];
	$stock=$_POST['stock'];
$shopid=$_POST['shopid'];
$no=$_POST['aisleno'];
$disc=$_POST['desc'];
$offer=$_POST['offer'];
$price=$_POST['pri'];
 /*echo $name;
 echo $stock;
 echo $shopid;
 echo $no;
 echo $disc;
 echo $offer;
 echo $proze;*/
        $fnm=$_FILE["pimage"]["name"];

        if($fnm==""){
            $query="UPDATE shoprite set prod_name='".$name."',stock='".$stock."',shop_id='$shopid',aisle_no='$no',describ='".$disc."',offer='".$offer."',price='$price' where prod_ID='$pid'";
			$data= mysqli_query($con,$query);
			 if($data){
	 echo "<script>alert('Details updated successfully')</script>"; 
	 }
	 else{
		 echo "<script>alert('An error occured')</script>"; 
	 }
		}else{
             $v1=rand(11111,99999);
            $v2=rand(11111,99999);
            $v3=rand(11111,99999);
            $v3=md5($v3);

            $fnm=$_FILES["img"]["name"];
            $dst="products/".$fnm;
            move_uploaded_file($_FILES["img"]["tmp_name"],$dst);
            mysqli_query($con,"UPDATE shoprite set img='$dst',prod_name='$_POST[pname]',stock='$_POST[stock]',shop_id='$_POST[shopid]',aisle_no='$_POST[aisleno]',describ='$_POST[desc]',offer='$_POST[offer]',price='$_POST[pri]' where prod_ID='$pid'");
        }
}
    
?>

