<?php
if (!empty($_GET['prod_ID'])) {
    // require connection
    require_once 'connection.php';

    $prod_ID = $_GET['prod_ID'];
    $del_query = "DELETE FROM `dmart` WHERE prod_ID = '" . $prod_ID . "'";
    $result = mysqli_query($con, $del_query);
    if ($result) {
        header('location:dmau.php?msg=del');
    }
}
?>