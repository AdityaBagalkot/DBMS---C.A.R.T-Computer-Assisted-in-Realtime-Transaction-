<?php 
session_start();
$connect = mysqli_connect("localhost", "root", "", "cart");
  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: main.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: main.php");
  }
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTC-8">
	<title>C.A.R.T-Home</title>
	<link rel="stylesheet" href="dma.css">
	<script type = "text/javascript" >
		function preventBack()
		{window.history.forward();}
			setTimeout("presentBack()",0);
			window.onunload=function(){null};
	</script>
</head>
<body>
<div class="hero">
<div class="container">
		<nav >
			<form id="login" class="input-group" action="selectpage.php">
			<div class="idiot">
				<a href="selectpage.php" style="text-decoration: none;
	font-family: Arial, Helvetica, sans-serif;
	position: absolute;
	right:-920px;
	top:-148px;
	color: white;
	border:none;
	font-size: 23px;
	padding:10px 10px;">Home</a>
				<a href="selectpage.php?logout='1'" style="text-decoration: none;
	font-family: Arial, Helvetica, sans-serif;
	position: absolute;
	right:-1100px;
	top:-150px;
	color: white;
	border:none;
	font-size: 22px;
	padding:10px 10px;">Logout</a>
			</div>
		</form>
		</nav>
	<a class="btn" href="dmai.php">Insert </a>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a class="btn" href="dmau.php">Update</a>
	<div class="row">
		<div class="col-1">
			<h1 style="color: white;"><br>D-Mart</h1>
		</div>
		</div>
</div>
</div>
</body>
</html>