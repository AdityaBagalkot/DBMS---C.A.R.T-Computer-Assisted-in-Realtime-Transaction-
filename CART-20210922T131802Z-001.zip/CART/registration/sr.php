<?php 
session_start();
$connect = mysqli_connect("localhost", "root", "", "cart");
  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: main.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: main.php");
  }
if(isset($_POST["add_to_cart"]))
{
    if(isset($_SESSION["shopping_cart"]))
    {
        $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
        if(!in_array($_GET["id"], $item_array_id))
        {
            $count = count($_SESSION["shopping_cart"]);
            $item_array = array(
            	'item_an'			=>	$_POST["hidden_an"],
            	'item_img'			=>  $_POST["hidden_img"],
                'item_id'           =>  $_GET["id"],
                'item_name'         =>  $_POST["hidden_name"],
                'item_price'        =>  $_POST["hidden_price"],
                'item_quantity'     =>  $_POST["quantity"]
            );
            $_SESSION["shopping_cart"][$count] = $item_array;
        }
        else
        {
            echo '<script>alert("Item Already Added")</script>';
        }
    }
    else
    {
        $item_array = array(
        	'item_an'			=>	$_POST["hidden_an"],
        	'item_img'			=>  $_POST["hidden_img"],
            'item_id'           =>  $_GET["id"],
            'item_name'         =>  $_POST["hidden_name"],
            'item_price'        =>  $_POST["hidden_price"],
            'item_quantity'     =>  $_POST["quantity"]
        );
        $_SESSION["shopping_cart"][0] = $item_array;
    }
}

if(isset($_GET["action"]))
{
    if($_GET["action"] == "delete")
    {
        foreach($_SESSION["shopping_cart"] as $keys => $values)
        {
            if($values["item_id"] == $_GET["id"])
            {
                unset($_SESSION["shopping_cart"][$keys]);
                echo '<script>alert("Item Removed")</script>';
                echo '<script>window.location="sr.php"</script>';
            }
        }
    }
}

?>
<!DOCTYPE html>
<html>
    <head>
    	<style>
body {
  background-image: url("hell.jpg");
  height: 100%;
  width: 100%;
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
		</style>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Cart-Shop@Rite</title>
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css' />
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css' />
        <link rel="stylesheet" href="sr.css">
</head>
<body >
  	<nav class="navbar navbar-expand-md bg-dark navbar-dark">
    <a class="navbar-brand" href="sr.php">&nbsp;&nbsp;Shop@Rite</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      	<ul class="navbar-nav ml-auto">
       	<li class="nav-item">
          <a class="nav-link" href="index2.php">&nbsp;Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about2.php">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="no.php">Logout</a>
        </li>
        <li class="nav-item">
          <a class="nav-link list" href="#" onclick="gfg_Run()">My List</a> 
        </li>
      	</ul>
    </div>
  	</nav>
        <div class="container">
         	<div class="row mt-2 pb-3">
            <?php
                $query = "SELECT * FROM shoprite ORDER BY prod_ID";
                $result = mysqli_query($connect, $query);
                if(mysqli_num_rows($result) > 0)
                {
                    while($row = mysqli_fetch_array($result))
                    {
                ?>
            <div class="col-sm-6 col-md-4 col-lg-3 mb-2">
                <div class="card-deck">
                <form method="post" action="sr.php?action=add&id=<?php echo $row["prod_ID"]; ?>">
                        <div class="card p-2 border-secondary mb-2">
                        <div class="sr">
                        <img src="<?php echo $row["img"]; ?>" class="card-img-top" height="200"/><br />
                        </div>
                        <div class="card-body p-1">
                        <h4 class="text-left text-info"><?php echo $row["prod_name"]; ?></h4>
                        <h6 class="card-title text-center"><?= $row['describ'] ?></h6>
                        <h6 class="card-title text-center">Aisle no : <?= $row['aisle_no'] ?></h6>
                        <h7 class="card-title text-center text-danger"> Stock left : <?= $row['stock'] ?></h7><br>
                        <h8 class="card-title text-center"><?= $row['offer'] ?></h8>
                        <h4 class="text-left text-danger"><i class="fas fa-rupee-sign"></i><?php echo $row["price"]; ?></h4>
                        </div>
                        <div class="row p-2">
                        <div class="col-md-6 py-1 pl-4">
                        <b>Quantity : </b>
                        </div>
                        <div class="col-md-6">
                        <input type="number" name="quantity" value="1" min="1" class="form-control text-center" >
                        </div>
                    	</div>
                    	<input type="hidden" name="hidden_img" value="<?php echo $row["img"]; ?>" />
                    	<input type="hidden" name="hidden_an" value="<?php echo $row["aisle_no"]; ?>" />
                        <input type="hidden" name="hidden_name" value="<?php echo $row["prod_name"]; ?>" />
                        <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />
                        <input type="submit" name="add_to_cart" style="margin-top:5px;background-color: #ff5733; font-weight: bold; color: #fff" class="btn btn-block" value="Add to My List" />
                		</div>
                </form>
            	</div>
        	</div>
            <?php
                    }
                }
            ?>
            <div style="clear:both"></div>
            <br>
            <br>
            <br>
            <br>
            <hr style="width:100%;text-align:left;margin-left:0">
            <br>
            <br>
            <div class="table-responsive">
            <table class="table table-bordered">
            <tr bgcolor="white">
            <h3 id="GFG_DOWN" style="text-align: center">My List</h3>
           	</tr>                
                    <tr bgcolor="lightblue">
                    	<th width="10%">Aisle</th>
                    	<th width="20%">Image</th>
                        <th width="30%">Item Name</th>
                        <th width="10%">Quantity</th>
                        <th width="10%">Price</th>
                        <th width="15%">Total</th>
                        <th width="5%">Action</th>
                    </tr>
                    <?php
                    if(!empty($_SESSION["shopping_cart"]))
                    {	$budget = 0;
                        $total = 0;
                        foreach($_SESSION["shopping_cart"] as $keys => $values)
                        {
                    ?>
                    <tr bgcolor="white">
                    	<td><?php echo $values["item_an"]; ?></td>
                    	<td><img src="<?php echo $values['item_img'] ?>" width="50"></td>
                        <td><?php echo $values["item_name"]; ?></td>
                        <td><?php echo $values["item_quantity"]; ?></td>
                        <td><i class="fas fa-rupee-sign"></i><?php echo $values["item_price"]; ?></td>
                        <td><i class="fas fa-rupee-sign"></i><?php echo number_format($values["item_quantity"] * $values["item_price"], 2);?></td>
                        <td><a href="sr.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger"><i class="fas fa-trash-alt"></i></span></a></td>
                    </tr>
                    <?php
                            $total += ($values["item_quantity"] * $values["item_price"]);
                            $budget = (18*$total)/100 + $total;
                        }
                    ?>
                    <tr bgcolor="white">
                        <td colspan="5" align="right">Total</td>
                        <td align="right"><i class="fas fa-rupee-sign"></i><?php echo number_format($total, 2); ?></td>
                        <td></td>
                    </tr>
                    <tr bgcolor="white">
                        <td colspan="5" align="right">GST</td>
                        <td align="right">+ 12%</td>
                        <td></td>
                    </tr>
                    <tr bgcolor="white">
                        <td colspan="5" align="right" class="text-danger" >Grand Total</td>
                        <td align="right" class="text-danger"><i class="fas fa-rupee-sign text-danger"></i><?php echo number_format($budget, 2); ?></td>
                        <td></td>
                    </tr>
                    <?php
                    }
                    ?>
                        
                </table>
            </div>
        </div>
    </div>
</div>
    <br />
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
  	<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js'></script>
  
  	<script> 
        var el_up = document.getElementById("GFG_UP"); 
        var el_down = document.getElementById("GFG_DOWN"); 
        el_up.innerHTML =  "Click on the button to scroll to the particular element."; 
  
        function gfg_Run() { 
            $('html, body').animate({ 
                scrollTop: $("#GFG_DOWN").offset().top 
            }, 500); 
        } 
    </script> 
</body>
</html>