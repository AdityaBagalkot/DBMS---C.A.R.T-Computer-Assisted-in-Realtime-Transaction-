<?php
	$userid = $_POST['userid'];
	$email = $_POST['email'];
	$password = $_POST['password'];

	$conn = new mysqli('localhost','root','','registration');
	if($conn->connect_error){
		die('Connection Failed : '.$conn->connect_error);
	}else{
		$stmt = $conn->prepare("insert into registration(user_id,email,password) values(?,?,?)");
		$stmt->bind_param("sss",$userid,$email,$password);
		$stmt->execute();
		echo "registration Success";
		$stmt->close();
		$conn->close();
	}
