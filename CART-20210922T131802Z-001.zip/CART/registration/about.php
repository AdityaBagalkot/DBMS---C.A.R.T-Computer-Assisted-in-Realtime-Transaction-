<?php include('server.php');?>
<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="UTC-8">
	<title>C.A.R.T-About</title>
	<link rel="stylesheet" href="about.css">
</head>
<body>
	<div class="hero">
		<div class="container">
	<div class="navbar">
		<nav>
		<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="about.php">About</a></li>
				<li><a href="stylesheet.php">Logout</a></li>
			</ul>
		</nav>
<div class="about-section">
	<div class="background">
  <div class="transbox">
  	  <h1>About Us </h1>
    <p>Here's bringing you, your friendlly shopping assistant <br>C.A.R.T(Computer Assistance in Real-time Transaction) <br> Making shopping even more convinient and easier than ever. <br>Tired of carrying your shopping list around the shop all the while asking where your product is? We got you covered, just click on the "Shop Now" button on your home page, select all the items you are looking for and know more about the offeres available for that item along with its location in the shop and more! Know the total price of your purchase before your checkout to stay clear of budget overflow. <br>All of these in one place. Register to login and start shopping now! </p>
                <h2> <br>-Team A & N </h2>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>

