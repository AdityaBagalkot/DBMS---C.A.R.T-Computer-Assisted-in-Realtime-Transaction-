<?php 
session_start();
$connect = mysqli_connect("localhost", "root", "", "cart");
  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: main.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: main.php");
  }
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTC-8">
	<title>C.A.R.T-Home</title>
	<link rel="stylesheet" href="selectpage.css">
	<script type = "text/javascript" >
		function preventBack()
		{window.history.forward();}
			setTimeout("presentBack()",0);
			window.onunload=function(){null};
	</script>

</head>
<body>
	<style>
	</style>
<div class="hero">
<div class="container">
		<div class="navbar" >
		<nav >
			<form id="login" class="input-group" action="selectpage.php">
			<div class="idiot">
				<a href="selectpage.php" style="text-decoration: none;
	font-family: Arial, Helvetica, sans-serif;
	position: absolute;
	left:-50px;
	top:-3px;
	color: white;
	border:none;
	font-size: 23px;
	padding:10px 10px;">Home</a>
				<a href="selectpage.php?logout='1'" style="text-decoration: none;
	font-family: Arial, Helvetica, sans-serif;
	position: absolute;
	left:100px;
	top:-3px;
	color: white;
	border:none;
	font-size: 23px;
	padding:10px 10px;">Logout</a>
			</div>
		</form>
		</nav>
	</div>
	<div class="btn">
	<a href="dma.php">D-Mart</a>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a  href="sra.php">ShopRite</a>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a  href="wa.php">Walmart</a>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a  href="sba.php">StarBazaar</a>
</div>
	<div class="row">
		<div class="col-1">
			<h1><br>Welcome, Admin</h1>
		</div>
		</div>
</div>
</div>
</body>
</html>