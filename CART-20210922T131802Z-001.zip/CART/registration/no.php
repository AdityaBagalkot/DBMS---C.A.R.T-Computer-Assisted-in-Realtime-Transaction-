<html>
<head>
	<title>C.A.R.T</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="hero">
		<div class="form-box">
			<div class="button-box">
				<div id="btn"></div>
				<button type="button" class="toggle-btn" onclick="login()">Log In</button>
				<button type="button" class="toggle-btn" onclick="register()">Register</button>
			</div>
			<form id="login" class="input-group" action="login.php" method="POST" >
				<input type="text" class="input-field" placeholder="Customer ID" required name="user" required>
				<input type="password" class="input-field" placeholder="Password" required name="pass" required>
				<div style="color:red;margin-bottom:15px;font-size:12px;font-family:arial;">
					<?php session_start();
					if(isset($_SESSION['message1'])){
						echo$_SESSION['message1'];
						unset($_SESSION['message1']);
					}
					session_destroy();
					?>
				</div>
				<input type="checkbox" class="chech-box"><span>Remember Password</span>
				<button type="submit" class="submit-btn" name="submit">Log In</button>
			</form>
			<form action="style.php" method="post" id="register" class="input-group">
				<input type="text" class="input-field" placeholder="*Customer Id"required name="user_id" required>
				<input type="email" class="input-field" placeholder="*Email ID"required name="email" required>
				<input type="password" class="input-field" placeholder="*Enter Password"required name="password" required>
				<input type="password" class="input-field" placeholder="*Confirm Password"required name="cpassword" required>
				<div style="color:red;margin-bottom:15px;font-size:17px;font-family:arial;">
					<?php session_start();
					if(isset($_SESSION['message1'])){
						echo$_SESSION['message1'];
						unset($_SESSION['message1']);
					}
					session_destroy();
					?>
				</div>
				<input type="checkbox" class="chech-box" required><span> I agree to the terms & conditions</span>
				<button type="submit" name="register" class="submit-btn">Register</button>
			</form>
		</div>
	</div>
	<script>
		var x=document.getElementById("login");
		var y=document.getElementById("register");
		var z=document.getElementById("btn");

		function register(){
			x.style.left = "-400px";
			y.style.left = "50px";
			z.style.left = "110px";
		}

		function login(){
			x.style.left = "50px";
			y.style.left = "450px";
			z.style.left = "0px";
		}
	</script>

</body>
</html>