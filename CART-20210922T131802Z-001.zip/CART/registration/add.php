<?php

if (isset($_POST['submit'])  ) {
    // require the db connection
    require_once 'connection.php';

    $prod_ID = (!empty($_POST['prod_ID'])) ? $_POST['prod_ID'] : '';
    $prod_name = (!empty($_POST['prod_name'])) ? $_POST['prod_name'] : '';
    $stock = (!empty($_POST['stock'])) ? $_POST['stock'] : '';
    $shop_id = (!empty($_POST['shop_id'])) ? $_POST['shop_id'] : '';
    $aisle_no = (!empty($_POST['aisle_no'])) ? $_POST['aisle_no'] : '';
    $describ = (!empty($_POST['describ'])) ? $_POST['describ'] : '';
    $img = (!empty($_POST['img'])) ? $_POST['img'] : '';
    $offer = (!empty($_POST['offer'])) ? $_POST['offer'] : '';
    $price = (!empty($_POST['price'])) ? $_POST['price'] : '';


     
        // update the record
        $stu_query = "UPDATE dmart set prod_name='".$prod_name."',stock='".$stock."',shop_id='$shop_id',aisle_no='$aisle_no',describ='".$describ."',offer='".$offer."',price='$price' where prod_ID='$prod_ID'";
        $msg = "update";
    

    $result = mysqli_query($con, $stu_query);

    if ($result) {
        header('location:dmau.php?msg=' . $msg);
    }

}

if (isset($_GET['prod_ID']) && $_GET['prod_ID'] != '') {
    // require the db connection
    require_once 'connection.php';

    $prod_ID = $_GET['prod_ID'];
    $stu_query = "SELECT * FROM `dmart` WHERE prod_ID='" . $prod_ID . "'";
    $stu_res = mysqli_query($con, $stu_query);
    $results = mysqli_fetch_row($stu_res);
	
	$prod_ID = $_GET['prod_ID']; 
    $prod_name = $results[1];
    $stock = $results[2];
    $price = $results[3];
    $shop_id = $results[4];
    $aisle_no = $results[5];
    $describ = $results[6];
    $img = $results[7];
    $offer = $results[8];
	
	

}else {
    $prod_ID = ""; 
    $prod_name = "";
    $stock = "";
    $price = "";
    $shop_id = "";
    $aisle_no = "";
    $describ = "";
    $img = "";
    $offer = "";
}
?>
<!DOCTYPE html>
<html >
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Student Attendence</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
    .formdiv { margin:0 auto; width:40% }
    .info { height: 20px;}
    </style>
</head>
<body style="background-image:linear-gradient(rgba(0,0,0,0.4),rgba(0,0,0,0.4)),url(leaf.jpg);height:100vh;
	background-position:center;
	background-size:cover;
	filter:blur(0px);">
<style>

.container{
	background:#252525;
	opacity:0.8;
	height:600px;
	color:white;
	border-radius:10px;
	margin-top:80px;

	
}
.form-control{
	color:white;
	background:black;
}
.success{
	background:#ff6600;
	left:50%;
	bottom:-50px;
	position:absolute;
	border:none;
	padding:8px 15px;
	border-radius:5px;
	
}
.success:hover{
	background:orange;
	transition:0.5s ease;
}
.nav{
	margin-bottom:10px;
	margin-top:10px;
	margin-left:10px;
	
}

.img{
    height: 350px;
    position: relative;
    left:60%;
    top:100px;
}
.form{
    position:absolute;
    left:15%;
    width:600px;
}

</style>
   
    <div class="container"  >
        <div class="formdiv">
        <div class="info"></div>
        <form method="POST" action="" class="form">
            <div class="form-group row" style="margin-top:55px;opacity:1;">
                <label for="first_name" class="col-sm-3 col-form-label">Product Name</label>
                <div class="col-sm-7">
                <input type="text" name="first_name" class="form-control" id="first_name" placeholder="First Name" value="<?php echo $prod_name; ?>">
                </div>
            </div>
            <div class="form-group row">
                <label for="last_name" class="col-sm-3 col-form-label">Product ID</label>
                <div class="col-sm-7">
                <input type="text" name="last_name" class="form-control" id="last_name" placeholder="product_id" value="<?php echo $prod_ID; ?>">
                </div>
            </div>
            <div class="form-group row">
                <label for="last_name" class="col-sm-3 col-form-label">Stock</label>
                <div class="col-sm-7">
                <input type="text" name="last_name" class="form-control" id="last_name" placeholder="stock" value="<?php echo $stock; ?>">
                </div>
            </div>
            <div class="form-group row">
            <label for="gender" class="col-sm-3 col-form-label">Price</label>
            <div class="col-sm-7">
                <input type="text" name="price" class="form-control" id="last_name" placeholder="Price" value="<?php echo $price; ?>">
                </div>
            </div>
            <div class="form-group row">
                <label for="shop" class="col-sm-3 col-form-label">Shop ID</label>
                <div class="col-sm-7">
                <input type="text" value="<?php echo $shop_id; ?>" name="email" class="form-control" id="email" placeholder="shop id">
                </div>
            </div>
            <div class="form-group row">
                <label for="email" class="col-sm-3 col-form-label">Aisle No</label>
                <div class="col-sm-7">
                <input type="text" value="<?php echo $aisle_no; ?>" name="email" class="form-control" id="email" placeholder="aisle no">
                </div>
            </div>
			<div class="form-group row">
                <label for="stud_id" class="col-sm-3 col-form-label">Description</label>
                <div class="col-sm-7">
                <input type="text" name="stud_id" class="form-control" id="stud_id" placeholder="desription" value="<?php echo $describ; ?>">
                </div>
            </div>

                <div class="form-group row">
                <label for="email" class="col-sm-3 col-form-label">Offer</label>
                <div class="col-sm-7">
                <input type="text" value="<?php echo $offer; ?>" name="email" class="form-control" id="email" placeholder="offer">
                </div>
            </div>
            
				<div class="col-sm-7">
                <input type="submit" name="submit" class="success" value="SUBMIT" style="">
                </div>

            </div>
            </form>
            <img  class="img" src="<?php echo $img; ?>">
        </div>
    </div>


                
</body>
</html>