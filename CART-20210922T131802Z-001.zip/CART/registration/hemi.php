<!DOCTYPE html>
<html>
<head>
<style>
body {
  background-image: url("dmart.jpg");
  height: 100%;
  width: 100%;
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
		</style>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Trial Run</title>
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css' />
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css' />
        <link rel="stylesheet" href="dm.css">
</head>
<body >
	<nav class="navbar navbar-expand-md bg-dark navbar-dark">
    <a class="navbar-brand" href="dm.php">&nbsp;&nbsp;D-Mart</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      	<ul class="navbar-nav ml-auto">
       	<li class="nav-item">
          <a class="nav-link" href="index2.php">&nbsp;Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about2.php">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="no.php">Logout</a>
        </li>
        <li class="nav-item">
          <a class="nav-link list" href="#" onclick="gfg_Run()">My List</a> 
        </li>
      	</ul>
    </div>
  	</nav>
<div class="product content-wrapper">
    <img src="imgs" width="500" height="500"s>
    <div>
        <h1 class="name"></h1>
        <span class="price">
            
        </span>
        <form action="index.php?page=cart" method="post">
            <input type="number" name="quantity" value="1" min="1" max="" placeholder="Quantity" required>
            <input type="hidden" name="product_id" value="">
            <input type="submit" value="Add To Cart">
        </form>
        <div class="description">
           
        </div>
    </div>
</div>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
  	<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js'></script> 
</body>
</html>