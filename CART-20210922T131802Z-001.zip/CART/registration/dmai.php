<?php 
session_start();
$connect = mysqli_connect("localhost", "root", "", "cart");
  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: main.php');
  }
  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: main.php");
  }
 ?>
 <!DOCTYPE html>
 <html>
 <body>
    <style>
        *{
                background-image: linear-gradient(rgba(0,0,0,0.4),rgba(0,0,0,0.4)),url(blue.jpg);

        }
       .submit{
        color: #ffffff;
    
    padding: 10px 150px;
    background: linear-gradient(to right, #ff5733, #ff5733);
    border: none;
    outline: none;
    border-radius: 30px;
    text-decoration: none;
    top:89%;
    position: absolute;
    left:16%;
}
.box{
    background: white;
    height:500px;
    width: 500px;
    position: absolute;
    left:33%;
    top: 13%;
    border-radius: 13px;

}
.title{
    text-align: center;
    font-family: Arial, Helvetica, sans-serif;
    margin-top: 50px;
    background: white;
}
.form{
     
    font-family: Arial, Helvetica, sans-serif;
    left:17%;
    position: absolute;
    background: transparent;

}
.item{
    width: 100%;
    padding: 10px 0;
    margin: -2px 0;
    border-left: 0;
    border-top: 0;
    border-right: 0;
    border-bottom: 2px solid #777;
    outline: none;
    background: white;
}    
.cant{
    background: white;
}
    </style>
 <div class="grid_10">
    <div class="box">
        <h2 class="title">
            Add Product
        </h2>
        <div class="block">
            <form name="form1" action="" method="post" enctype="multipart/form-data">
                <table class="form" >
                    <tr class="item">
                        <td class="cant" > Product ID</td>
                        <td ><input type="text" name="pid" placeholder="Product ID" class="item" ></td>
                    </tr>

                     <tr>
                        <td class="cant"> Product Name</td>
                        <td><input type="text" name="pnm" placeholder="Product Name" class="item" ></td>
                    </tr>

                    <tr>
                        <td class="cant"> Stock</td>
                        <td><input type="text" name="pst" placeholder="Stock" class="item" ></td>
                    </tr>

                    <tr>
                        <td class="cant">Price</td>
                        <td><input type="text" name="pri" placeholder="Price" class="item"></td>
                    </tr>

                    <tr>
                        <td class="cant">Shop ID</td>
                        <td><input type="text" name="sid" placeholder="Shop ID" class="item"></td>
                    </tr>

                    <tr>
                        <td class="cant">Aisle Number</td>
                        <td><input type="text" name="ano" placeholder="Aisle Number" class="item"></td>
                    </tr>

                    <tr>
                        <td class="cant">Description</td>
                        <td><input type="text" name="des" placeholder="Description" class="item"></td>
                    </tr>

                    <tr>
                        <td class="cant"> Image</td>
                        <td ><input type="file" name="img" placeholder="Image"class="item"></td>
                    </tr>


                    <tr>
                        <td class="cant">Offer</td>
                        <td><input type="text" name="off" placeholder="Offer" class="item"></td>
                    </tr>

                    
                </table>
                <a href="dma.php" class="submit">Upload</a>
            </form>
        </div>
    </div>
</div>
    </body>
</html>
<?php 
if(isset($_POST["submit1"])){
    $v1=rand(11111,99999);
    $v2=rand(11111,99999);
    $v3=rand(11111,99999);
    $v3=md5($v3);

    $fnm=$_FILES["img"]["name"];
    $dst="products/".$fnm;
    move_uploaded_file($_FILES["img"]["tmp_name"],$dst);
    mysqli_query($con, "INSERT into dmart values('$_POST[pid]','$_POST[pnm]','$_POST[pst]','$_POST[pri]','$_POST[sid]','$_POST[ano]','$_POST[des]','$_POST[off]')");

}
?>
        </div>
    </div>
    </div>
<?php
?>
