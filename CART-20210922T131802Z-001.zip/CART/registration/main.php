<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTC-8">
	<title>C.A.R.T-Home</title>
	<link rel="stylesheet" href="main.css">
	<script type = "text/javascript" >
		function preventBack()
		{window.history.forward();}
			setTimeout("presentBack()",0);
			window.onunload=function(){null};
	</script>
</head>
<body>
<div class="hero">
<div class="container">
	<a class="btn" href="admin.php">ADMIN</a>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a class="btn" href="no.php">CONSUMER</a>
	<div class="row">
		<div class="col-1">
			<h1 style="color: white">Welcome to <br></h1>
			<h2 style="color:white;">C.A.R.T</h2>
			<p style="color:white;">Your friendly shopping assistant</p>
		</div>
		</div>
</div>
</div>
</body>
</html>