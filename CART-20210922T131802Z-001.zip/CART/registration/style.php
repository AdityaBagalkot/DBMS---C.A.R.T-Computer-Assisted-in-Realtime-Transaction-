<?php
	session_start();
	$username = $_POST['user_id'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$cpassword = $_POST['cpassword'];
	$errors = array();

	if (!empty($username) || !empty($email) || !empty($password)){
		$host = "localhost";
		$dbUsername = "root";
		$dbPassword = "";
		$dbname = "cart";

		$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

		if(mysqli_connect_error()){
			die('Connect Error('.mysqli_connect_errno().')'.mysqli_connect_error());
		}else{
			$sql_u = "SELECT * FROM users WHERE username='$username'";
			$sql_e = "SELECT * FROM users WHERE email = '$email'";
			$res_u = mysqli_query($conn, $sql_u) or die(mysqli_error($conn));
			$res_e = mysqli_query($conn, $sql_e) or die(mysqli_error($conn));

			if(mysqli_num_rows($res_u) > 0){
				$_SESSION['message1'] = "User Already Exists";
				header("location:no.php");
			}
			else if(mysqli_num_rows($res_e) > 0){
				$_SESSION['message1'] = "Email Already Exists";
				header("location:no.php");
			}else{
			if($password != $cpassword){
				$_SESSION['message1'] = "Passwords Do Not Match";
				header("location:no.php");
			}
			else{
			$SELECT = "SELECT email  from users Where email = ? Limit 1";
			$INSERT = "INSERT INTO users (username, email, password) values (?,?,?)";
			$stmt = $conn->prepare($SELECT);
			$stmt->bind_param("s",$email);
			$stmt->execute();
			$stmt->bind_result($email);
			$stmt->store_result();
			$rnum = $stmt->num_rows;
			$stmt->close();
			$stmt = $conn->prepare($INSERT);
			$stmt->bind_param("sss", $username, $email, $password);
			$stmt->execute();
			$_SESSION['username'] = $username;
			 echo "<script> location.href='index2.php'; </script>";
        		exit;
			$stmt->close();
			$conn>close();
			}
		}}
	}else{
		echo "All fields are required";
		die();
	}
?>





