<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: main.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: main.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTC-8">
	<title>C.A.R.T-Home</title>
	<link rel="stylesheet" href="homestyle.css">
	<script type = "text/javascript" >
		function preventBack()
		{window.history.forward();}
			setTimeout("presentBack()",0);
			window.onunload=function(){null};
	</script>
</head>
<body>
<div class="hero">
<div class="container">
	<div class="navbar">
		<div class="logo">
			<a href="index2.php"><img src="ml.png" width="100px" height="80px"></a>
		</div>
		<nav>
			<form id="login" class="input-group" action="index2.php">
			<ul>
				<li><a href="index2.php">Home</a></li>
				<li><a href="about2.php">About</a></li>
				<li><a href="index2.php?logout='1'">Logout</a></li>

			</ul>
		</form>
		</nav>
	</div>
	<div class="row">
		<div class="col-1">
			<h1>Welcome to <br></h1>
			<h2>C.A.R.T</h2>
			<p>Your friendly shopping assistant</p>
			<a href="shop2.php" class="btn"> Shop Now &#8594;</a>
            <h3> &#169; &nbsp; 2020 Team A & N </h3>
		</div>
		

		</div>
	</div>
</div>
</div>
</div>
</body>
</html>