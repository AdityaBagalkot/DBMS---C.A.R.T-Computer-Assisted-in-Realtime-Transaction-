<?php
session_start();
$connect = mysqli_connect("localhost", "root", "", "cart");
  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: main.php');
  }
  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: main.php");
  }
if (!empty($_GET['pid'])) {
    require_once 'connection.php';

    $prodid = $_GET['pid'];
    $del_query = "DELETE FROM `starbazzar` WHERE prod_ID = '" . $prodid . "'";
    $result = mysqli_query($con, $del_query);
    if ($result) {
        header('location:dmau.php?msg=del');
    }
}