<?php 
session_start();
$connect = mysqli_connect("localhost", "root", "", "cart");
  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: main.php');
  }
  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: main.php");
  }
 ?>
 <div class="grid_10">
    <div class="box round first">
        <h2>
            Add Product
        </h2>
        <div class="block">
            <form name="form1" action="" method="post" enctype="multipart/form-data">
                <table>
                    <tr>
                        <td> Product ID</td>
                        <td><input type="text" name="pid" ></td>
                    </tr>

                     <tr>
                        <td> Product Name</td>
                        <td><input type="text" name="pnm"></td>
                    </tr>

                    <tr>
                        <td> Stock</td>
                        <td><input type="text" name="pst"></td>
                    </tr>

                    <tr>
                        <td>Price</td>
                        <td><input type="text" name="pri"></td>
                    </tr>

                    <tr>
                        <td>Shop ID</td>
                        <td><input type="text" name="sid"></td>
                    </tr>

                    <tr>
                        <td>Aisle Number</td>
                        <td><input type="text" name="ano"></td>
                    </tr>

                    <tr>
                        <td>Description</td>
                        <td><input type="text" name="des"></td>
                    </tr>

                    <tr>
                        <td> Image</td>
                        <td><input type="file" name="img"></td>
                    </tr>


                    <tr>
                        <td>Offer</td>
                        <td><input type="text" name="off"></td>
                    </tr>

                    <td colspan="2" align="center"><input type="submit" name="submit1" value="Upload"></td>
                </table>
            </form>
<?php 
if(isset($_POST["submit1"])){
    $v1=rand(11111,99999);
    $v2=rand(11111,99999);
    $v3=rand(11111,99999);
    $v3=md5($v3);

    $fnm=$_FILES["img"]["name"];
    $dst="products/".$fnm;
    move_uploaded_file($_FILES["img"]["tmp_name"],$dst);
    mysqli_query($con, "INSERT into starbazzar values('$_POST[pid]','$_POST[pnm]','$_POST[pst]','$_POST[pri]','$_POST[sid]','$_POST[ano]','$_POST[des]','$_POST[off]')");

}
?>
        </div>
    </div>
    </div>
<?php
?>
