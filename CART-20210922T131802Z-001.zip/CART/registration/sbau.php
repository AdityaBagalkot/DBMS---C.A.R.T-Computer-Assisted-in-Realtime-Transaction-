<?php 
include"connection.php";
session_start();
$connect = mysqli_connect("localhost", "root", "", "cart");
  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: main.php');
  }
  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: main.php");
  }
 
 $query = " select * from starbazzar ";
    $result = mysqli_query($con,$query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" a href="CSS/bootstrap.css"/>
    <title>Student Records</title>
</head>
<body class="bg-dark">
    <style> 
        *{
            margin: 1% auto;
            padding-top: 0;
        }
        table, th, td { 
            border: 1px solid black; 
            border-collapse: collapse; 
        } 
        th, td { 
            padding: 20px; 
        } 
        th { 
            text-align: left; 
        } 
    </style> 
        <div class="container">
            <div class="row">
                <div class="col m-auto">
                    <div class="card mt-5">
                        <table class="table table-bordered" style="width: 70%">
                            <tr>
                                <th> Product ID </th>
                                <th> Product Name </th>
                                <th> Stock</th>
                                <th> Shop ID </th>
                                <th> Aisle No </th>
                                <th> Descrption </th>
                                <th> Image </th>
                                <th> Offer </th>
                                <th> Price </th>
                                <th colspan="2">Operations</th>
                              
                            </tr>

                            <?php 
                                    
                                    while($row=mysqli_fetch_assoc($result)){
                                        echo "<tr>
                                            <td>".$row['prod_ID']."</td>
                                            <td>".$row['prod_name']."</td>
                                            <td>".$row['stock']."</td>
                                            <td>".$row['shop_id']."</td>
                                            <td>".$row['aisle_no']."</td>
                                            <td>".$row['describ']."</td>
                                            <td>".$row['img']."</td>
                                            <td>".$row['offer']."</td>
                                            <td>".$row['price']."</td>
                                            <td><a href='dup.php?pid=$row[prod_ID]&pn=$row[prod_name]&st=$row[stock]&sid=$row[shop_id]&ano=$row[aisle_no]&des=$row[describ]&img=$row[img]&off=$row[offer]&price=$row[price]'>Edit</td>
                                            <td><a href='ddel.php?pid=$row[prod_ID]'>Delete</td>
                                            </tr>";
                                    }
                            
                            ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    
</body>
</html>