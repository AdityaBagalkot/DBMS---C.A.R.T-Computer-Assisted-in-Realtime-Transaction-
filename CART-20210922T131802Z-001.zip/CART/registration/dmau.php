<?php
// mysql connection
require_once 'connection.php';
$query = "SELECT * FROM `dmart`";

$results = mysqli_query($con, $query);
$records = mysqli_num_rows($results);
$msg = "";
if (!empty($_GET['msg'])) {
    $msg = $_GET['msg'];
    $alert_msg = ($msg == "add") ? "Record has been added successfully!" : (($msg == "del") ? "Record has been deleted successfully!" : "Record has been updated successfully!");
} else {
    $alert_msg = "";
}

?>
<!DOCTYPE html>
<html lang="en" >
<?php //include 'head.php';?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>DMART</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
    .formdiv { margin:0 auto; width:40% }
    .info { height: 20px;}
    </style>
</head>
<body style="background-image:linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url(about_bg.jpg);height:100vh;
    background-position:center;
    background-size:cover;
    filter:blur(0px);">
<style>
.button{
    border:none;
    color:white;
    background:#3caea3;
    position:absolute;
    right:3%;
    top:15px;
    padding:10px 10px;
    border-radius:5px;
    font-size:20px;
}
.button:hover{
    background:#80cbc4;
    transition:1s ease;
    padding-right:15px;
    padding-left:15px;
}
.table{
    color:black;
}
.container {
    background:#fff;
    border-radius:8px;
    opacity:0.8;
    width: 100%;
}
.list{
    border:none;
    background:transparent;
    
    color:white;
    padding:10px 10px;
    border-radius:10px;
    font-size:25px;
    margin-right:7px;
}
.list:hover{
    border:2px solid gray transparent;
    border-radius:30px;
    background:#e0e0e0;
    opacity:0.5;
    color:#000;
    transition:1s ease;
    padding-right:15px;
    padding-left:15px;
}
.nav{
    margin-bottom:10px;
    margin-top:10px;
    margin-left:10px;
    
}
.list1{
    
    border-radius:30px;
    background:#e0e0e0;
    opacity:0.5;
    color:#000;
    transition:0.7s ease;
    padding:10px 10px;
    font-size:25px;
    margin-right:10px;
}
</style>

<script src="https://kit.fontawesome.com/a076d05399.js"></script>

   <?php //include 'nav.php';?>
   <div class="nav">
        <a href="selectpage.php" ><button class="list">Home</button></a>
        <a href="main.php?logout=1"><button class="list">Logout</button></a>
   </div>
    <form class="container" >
    
<?php if (!empty($alert_msg)) {?>
        <div class="alert alert-success"><?php echo $alert_msg; ?></div>
<?php }?>
    <div class="info"></div>
        <table class="table" >
            <thead action="/action_page.php">
                <tr>
                <th scope="col">Product ID</th>
                <th scope="col">Product Name</th>
                <th scope="col">Stock</th>
                <th scope="col">Shop ID</th>
                <th scope="col">Aisle No</th>
                <th scope="col">Description</th>
                <th scope="col">Image</th>
                <th scope="col">Offer</th>
                <th scope="col">Price</th>
                <th scope="col">Operations</th>
                
                </tr>
            </thead>
            <tbody>
                <?php
if (!empty($records)) {
    while ($row = mysqli_fetch_assoc($results)) {
        ?>
                                <tr >
                                    <td style="text-transform: uppercase;"><?php echo $row['prod_ID']; ?></td>
                                    <td><?php echo $row['prod_name']; ?></td>
                                    <td><?php echo $row['stock']; ?></td>
                                    <td><?php echo $row['shop_id']; ?></td>
                                    <td><?php echo $row['aisle_no']; ?></td>
                                    <td><?php echo $row['describ']; ?></td>
                                    <td><?php echo $row['img']; ?></td>
                                    <td><?php echo $row['offer']; ?></td>
                                    <td>₹<?php echo $row['price']; ?></td>
                                     <td >
                                        <a href="add.php?prod_ID=<?php echo $row['prod_ID']; ?>" class="btn btn-primary" style="margin-bottom: 5px;">EDIT</a>
                                        <a href="ddel.php?prod_ID=<?php echo $row['prod_ID']; ?>" class="btn btn-danger" onClick="javascript:return confirm('Do you really want to delete?');" >DELETE</a>
                                                

    </div>
                                </tr>

                            <?php
}
}
?>



            </tbody>
        </table>
        
    </form>
    

</body>
                                    
</html>