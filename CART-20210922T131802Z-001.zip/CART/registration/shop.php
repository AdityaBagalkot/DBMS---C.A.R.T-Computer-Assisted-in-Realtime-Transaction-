<?php include('server.php');?>
<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="UTC-8">
	<title>C.A.R.T-Shop-Hour</title>
	<link rel="stylesheet" href="shopstyle.css">
</head>
<body>

	<div class="hero">
			<div class="container">
	<div class="navbar">
		<nav>
				<h4>Shop-Hour</h4>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="about.php">About</a></li>
				<li><a href="stylesheet.php">Logout</a></li>
			</ul>
		</nav>
	</div>
</div>
</div>
</div>
</body>
</html>