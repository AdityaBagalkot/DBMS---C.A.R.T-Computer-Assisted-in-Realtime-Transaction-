<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: main.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: main.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTC-8">
	<title>C.A.R.T-Shop-Hour</title>
	<link rel="stylesheet" type=text/css href="shopstyle.css?v=<?php echo time();?>">
	<script type = "text/javascript" >
		function preventBack()
		{window.history.forward();}
			setTimeout("presentBack()",0);
			window.onunload=function(){null};
	</script>
</head>
<body>
<div class="hero">
	<div class="container">
	<div class="navbar">
		<nav>
				<h4>Shop-Hour</h4>
			<ul>
				<li><a href="index2.php">Home</a></li>
				<li><a href="about2.php">About</a></li>
				<li><a href="shop2.php?logout='1'">Logout</a></li>
			</ul>
			<div class="slider">
				<div class="slides">
					<input type="radio" name="radio-btn" id="radio1">
					<input type="radio" name="radio-btn" id="radio2">
					<input type="radio" name="radio-btn" id="radio3">
					<input type="radio" name="radio-btn" id="radio4">

					<div class="slide first">
						<a href="sc.php"><img src="sc.png" width="400px" height="250px" alt=""></a>
					</div>
					<div class="slide">
						<a href="sb.php"><img src="sb.png" width="400px" height="250px" alt=""></a>
					</div>
					<div class="slide">
						<a href="sr.php"><img src="sr.png" width="400px" height="250px" alt=""></a>
					</div>
					<div class="slide">
						<a href="dm.php"><img src="dm.png" width="400px" height="250px" alt=""></a>
					</div>

					<div class="navi-auto">
						<div class="auto1"></div>
						<div class="auto2"></div>
						<div class="auto3"></div>
						<div class="auto4"></div>
					</div>
				</div>
					<div class="navi-manual">
						<label for="radio1" class="man-btn"></label>
						<label for="radio2" class="man-btn"></label>
						<label for="radio3" class="man-btn"></label>
						<label for="radio4" class="man-btn"></label>
					</div>
				</div>
				<script type="text/javascript">
				var counter = 1;
				setInterval(function(){
					document.getElementById('radio' + counter).checked = true;
					counter++;
					if(counter>4){
						counter=1;
					}
				}, 5000);
				</script>
			</nav>
		</div>
	</div>
</div>
</body>
</html>