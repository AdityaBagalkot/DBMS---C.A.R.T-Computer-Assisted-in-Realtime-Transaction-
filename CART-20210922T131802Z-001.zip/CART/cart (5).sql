-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2021 at 05:43 AM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cart`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `email`, `password`) VALUES
('12345', '12@12', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `dmart`
--

CREATE TABLE `dmart` (
  `prod_ID` int(10) NOT NULL,
  `prod_name` varchar(50) NOT NULL,
  `stock` varchar(10) NOT NULL,
  `price` float NOT NULL,
  `shop_id` int(5) NOT NULL,
  `aisle_no` int(2) DEFAULT NULL,
  `describ` varchar(250) NOT NULL,
  `img` varchar(10000) NOT NULL,
  `offer` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dmart`
--

INSERT INTO `dmart` (`prod_ID`, `prod_name`, `stock`, `price`, `shop_id`, `aisle_no`, `describ`, `img`, `offer`) VALUES
(1415603, 'Comfort Fabric Freshner', '20pc', 149, 141, 5, 'Comfort makes a good clothes day', 'comf4.jfif', ''),
(1415605, 'Sugar', '80kg', 45, 141, 5, 'Sweet is never enough', 'sug4.jfif', '10%off'),
(1415607, '123 Maggie', '40pc', 12, 141, 4, 'Taste of Magic', '123.jpg', '10%off'),
(1415609, 'Dettol Handwash', '50pc', 149, 141, 5, 'Keep the memories, but not the bacteria', 'det4.jfif', '25%off'),
(1415611, 'Huggies Diapers', '25pc', 15, 141, 5, ' There\'s nothing like a hug. What happens in Huggies stays in Huggies.', 'hug4.jfif', '20%off'),
(1415612, 'Papergrid Notebooks', '80pc', 79, 141, 3, 'Unbeatable quality', 'pg1.jpg', NULL),
(1415615, 'Fixit Glue', '80pc', 100, 141, 3, 'Fix it forever!', 'fi1.jpg', NULL),
(1415617, 'Wattagirl Perfume', '40pc', 149, 141, 4, 'dil ki baat deal se', 'wg4.jpg', NULL),
(1415619, 'Real Juice', '40pc', 149, 141, 2, 'My Real Fruit Power', 'real1.png', '25%off');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `prod_ID` int(10) NOT NULL,
  `prod_name` varchar(20) NOT NULL,
  `stock` varchar(10) NOT NULL,
  `price` float NOT NULL,
  `shop_id` int(5) NOT NULL,
  `aisle_no` int(2) DEFAULT NULL,
  `describ` varchar(250) NOT NULL,
  `img` varchar(10000) NOT NULL,
  `offer` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`prod_ID`, `prod_name`, `stock`, `price`, `shop_id`, `aisle_no`, `describ`, `img`, `offer`) VALUES
(1115600, 'curtains', '10pc', 299, 111, 5, '', '', '7%off'),
(1115601, 'lizol_floor_cleaner', '7pc', 180, 111, 4, '', '', '10%of'),
(1115602, 'dove_soap', '6pc', 35, 111, 4, '', '', '5%off'),
(1115603, 'comfort_ff', '6pc', 149, 111, 4, '', '', 'none'),
(1115604, 'apple', '15kg', 180, 111, 4, '', '', '7%off'),
(1115605, 'sugar', '50kg', 79, 111, 5, '', '', 'none'),
(1115606, '3roses_tea', '20pc', 55, 111, 4, '', '', 'none'),
(1115607, '123maggie', '40pc', 12, 111, 4, '', '', '10%of'),
(1115608, 'himalaya_ph', '20pc', 55, 111, 5, '', '', '10%of'),
(1115609, 'dettol_hw', '40pc', 249, 111, 5, '', '', '15%of'),
(1115610, 'vicks_vr', '20pc', 79, 111, 5, '', '', 'none'),
(1115611, 'huggies', '25pc', 15, 111, 5, '', '', '20%of'),
(1115612, 'papergrid_nb', '100pc', 79, 111, 3, '', '', NULL),
(1115613, 'camel_wc', '50pc', 45, 111, 3, '', '', NULL),
(1115614, 'fevicol', '45pc', 20, 111, 3, '', '', NULL),
(1115615, 'fixit', '100pc', 112, 111, 3, '', '', NULL),
(1115616, 'everyuth_limefw', '30pc', 145, 111, 4, '', '', '17%of'),
(1115617, 'wattagir_perf', '40pc', 149, 111, 4, '', '', NULL),
(1115618, 'essential_oil', '100pc', 199, 111, 4, '', '', NULL),
(1115619, 'real_juice', '30pc', 149, 111, 2, '', '', '25%of'),
(1215600, 'curtains', '15pc', 299, 121, 2, '', '', '10%of'),
(1215601, 'lizol_floor_cleaner', '7pc', 190, 121, 5, '', '', ''),
(1215602, 'dove_soap', '6pc', 35, 121, 4, '', '', '5%off'),
(1215603, 'comfort_ff', '6pc', 149, 121, 4, '', '', 'none'),
(1215605, 'sugar', '50kg', 79, 121, 5, '', '', 'none'),
(1215606, '3roses_tea', '20pc', 55, 121, 4, '', '', 'none'),
(1215607, '123maggie', '40pc', 12, 121, 4, '', '', '10%of'),
(1215608, 'himalaya_ph', '20pc', 55, 121, 5, '', '', '10%of'),
(1215609, 'dettol_hw', '40pc', 249, 121, 5, '', '', '15%of'),
(1215610, 'vicks_vr', '20pc', 79, 121, 5, '', '', 'none'),
(1215612, 'papergrid_nb', '100pc', 79, 121, 3, '', '', NULL),
(1215613, 'camel_wc', '50pc', 45, 121, 3, '', '', NULL),
(1215614, 'fevicol', '45pc', 20, 121, 3, '', '', NULL),
(1215615, 'fixit', '100pc', 112, 121, 3, '', '', NULL),
(1215616, 'everyuth_limefw', '30pc', 145, 121, 4, '', '', '17%of'),
(1215619, 'real_juice', '30pc', 149, 121, 4, '', '', '25%of'),
(1315600, 'curtains', '20pc', 122, 131, 5, '', '', '50%of'),
(1315601, 'lizol_floor_cleaner', '15pc', 150, 131, 4, '', '', '15%of'),
(1315602, 'dove_soap', '6pc', 35, 131, 4, '', '', '5%off'),
(1315604, 'apple', '15kg', 100, 131, 2, '', '', '15%of'),
(1315605, 'sugar', '50kg', 79, 131, 5, '', '', 'none'),
(1315606, '3roses_tea', '20pc', 55, 131, 4, '', '', 'none'),
(1315607, '123maggie', '40pc', 12, 131, 4, '', '', '10%of'),
(1315608, 'himalaya_ph', '20pc', 75, 131, 5, '', '', ''),
(1315609, 'dettol_hw', '40pc', 150, 131, 3, '', '', '50%of'),
(1315611, 'huggies', '25pc', 15, 131, 2, '', '', '20%of'),
(1315612, 'papergrid_nb', '100pc', 79, 131, 3, '', '', NULL),
(1315614, 'fevicol', '45pc', 20, 131, 4, '', '', NULL),
(1315615, 'fixit', '85pc', 112, 131, 4, '', '', NULL),
(1315616, 'everyuth_limefw', '45pc', 145, 131, 2, '', '', '17%of'),
(1315617, 'wattagir_perf', '50pc', 149, 131, 1, '', '', NULL),
(1315618, 'essential_oil', '80pc', 299, 131, 1, '', '', NULL),
(1315619, 'real_juice', '50pc', 149, 131, 1, '', '', '25%of'),
(1415600, 'curtains', '20pc', 299, 141, 4, '', '', ''),
(1415602, 'dove_soap', '25pc', 45, 141, 4, '', '', ''),
(1415603, 'comfort_ff', '20pc', 149, 141, 5, '', '', ''),
(1415605, 'sugar', '80kg', 45, 141, 5, '', '', '10%of'),
(1415607, '123maggie', '40pc', 12, 141, 4, '', '', '10%of'),
(1415609, 'dettol_hw', '50pc', 149, 141, 5, '', '', '25%of'),
(1415611, 'huggies', '25pc', 15, 141, 5, '', '', '20%of'),
(1415612, 'papergrid_nb', '80pc', 79, 141, 3, '', '', NULL),
(1415615, 'fixit', '80pc', 100, 141, 3, '', '', NULL),
(1415617, 'wattagir_perf', '40pc', 149, 141, 4, '', '', NULL),
(1415619, 'real_juice', '40pc', 149, 141, 2, '', '', '25%of');

-- --------------------------------------------------------

--
-- Table structure for table `shoprite`
--

CREATE TABLE `shoprite` (
  `prod_ID` int(10) NOT NULL,
  `prod_name` varchar(20) NOT NULL,
  `stock` varchar(10) NOT NULL,
  `price` float NOT NULL,
  `shop_id` int(5) NOT NULL,
  `aisle_no` int(2) DEFAULT NULL,
  `describ` varchar(250) NOT NULL,
  `img` varchar(10000) NOT NULL,
  `offer` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shoprite`
--

INSERT INTO `shoprite` (`prod_ID`, `prod_name`, `stock`, `price`, `shop_id`, `aisle_no`, `describ`, `img`, `offer`) VALUES
(1315600, 'Curtains', '20pc', 122, 131, 5, 'Beautiful drapes', 'curt3.jfif', '50%off'),
(1315601, 'Lizol Floor Cleaner', '15pc', 150, 131, 4, 'Healthing', 'liz3.jfif', '15%off'),
(1315602, 'Dove Soaps', '6pc', 35, 131, 4, 'Put your best face forward', 'd3.jfif', '5%off'),
(1315604, 'Apples', '15kg', 100, 131, 2, 'An apple a day, keeps medical expenses away!', 'ap3.jfif', '15%off'),
(1315605, 'Sugar', '50kg', 79, 131, 5, 'Sweet is never enough', 'sug3.jfif', '12%off'),
(1315606, '3 Roses Tea Poweder', '20pc', 55, 131, 4, 'The finest tea on earth', 'ro3.jfif', 'none'),
(1315607, '123 Maggie', '40pc', 12, 131, 4, 'Taste of Magic', '3.jpg', '10%off'),
(1315608, 'Himalaya Pure Hands', '20pc', 75, 131, 5, 'kills 99.9% of germs', 'hp3.jfif', ''),
(1315609, 'Dettol Hand Wash', '40pc', 150, 131, 3, 'Keep the memories, but not the bacteria', 'det3.jfif', '50%off'),
(1315611, 'Huggies Diapers', '25pc', 15, 131, 2, ' There\'s nothing like a hug. What happens in Huggies stays in Huggies.', 'hug3.jfif', '20%off'),
(1315612, 'Papergrid Notebooks', '100pc', 79, 131, 3, 'Unbeatable quality', 'pg3.jpg', NULL),
(1315614, 'Fevicol Glue', '45pc', 20, 131, 4, 'Fevicol ka mazboot jod hai Tootega nahi!', 'fc3.jpeg', NULL),
(1315615, 'Fixit Glue', '85pc', 112, 131, 4, 'Fix it forever!', 'fi3.jpeg', NULL),
(1315616, 'Everyuth Facewash', '45pc', 145, 131, 2, 'Amazing combos with end of seasons price', 'ey3.png', '17%off'),
(1315617, 'Wottagirl Perfume', '50pc', 149, 131, 1, 'dil ki baat deal se', 'wg3.jpg', NULL),
(1315618, 'Essential Oil', '80pc', 299, 131, 1, 'Packed with the essentials', 'eo3.jpg', NULL),
(1315619, 'Real Juice', '50pc', 149, 131, 1, 'My Real Fruit Power', 'real3.jpg', '25%off');

-- --------------------------------------------------------

--
-- Table structure for table `shops`
--

CREATE TABLE `shops` (
  `shop_id` int(5) NOT NULL,
  `shop_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shops`
--

INSERT INTO `shops` (`shop_id`, `shop_name`) VALUES
(111, 'walmart'),
(121, 'starbazzar'),
(131, 'shoprite'),
(141, 'dmart');

-- --------------------------------------------------------

--
-- Table structure for table `starbazzar`
--

CREATE TABLE `starbazzar` (
  `prod_ID` int(10) NOT NULL,
  `prod_name` varchar(50) NOT NULL,
  `stock` varchar(10) NOT NULL,
  `price` float NOT NULL,
  `shop_id` int(5) NOT NULL,
  `aisle_no` int(2) DEFAULT NULL,
  `describ` varchar(250) NOT NULL,
  `img` varchar(10000) NOT NULL,
  `offer` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `starbazzar`
--

INSERT INTO `starbazzar` (`prod_ID`, `prod_name`, `stock`, `price`, `shop_id`, `aisle_no`, `describ`, `img`, `offer`) VALUES
(1215600, 'Curtains', '15pc', 299, 121, 2, 'Beautiful light colored drapes', 'curt1.jpg', '10%off'),
(1215601, 'Lizol Floor Cleaner', '7pc', 190, 121, 5, 'Healthing', 'liz1.jfif', '7%off'),
(1215602, 'Dove Soap', '6pc', 35, 121, 4, 'Put your best face forward with Dove', 'd1.jfif', '5%off'),
(1215603, 'Comfort Fabric Freshner', '6pc', 149, 121, 4, 'Comfort makes a good clothes day', 'comf1.jfif', 'none'),
(1215605, 'Sugar', '50kg', 79, 121, 5, 'Sweet is never enough', 'sug1.jfif', '10%off'),
(1215606, '3 Roses Tea Powder', '20pc', 55, 121, 4, 'The finest tea on earth', '3roses.jfif', '7%off'),
(1215607, '123 Maggie', '40pc', 12, 121, 4, 'pinch of magic', '123.jpg', '10%off'),
(1215608, 'Himalaya Pure Hands', '20pc', 55, 121, 5, 'kills 99.9% of germs', 'hp1.jfif', '10%off'),
(1215609, 'Dettol Hand Wash', '40pc', 249, 121, 5, 'Keep the memories, but not the bacteria', 'det1.jfif', '15%off'),
(1215610, 'Vicks Vapor rub', '20pc', 79, 121, 5, 'Breathe Life In', 'vv1.jfif', NULL),
(1215612, 'Papergrid Notebook', '100pc', 79, 121, 3, 'Unbeatable quality', 'pg1.jpg', NULL),
(1215613, 'Camel Water Color', '50pc', 45, 121, 3, 'Har din colourful!', 'cw1.jpg', NULL),
(1215614, 'Fevicol Glue', '45pc', 20, 121, 3, 'Fevicol ka mazboot jod hai Tootega nahi!', 'fc1.jpg', NULL),
(1215615, 'Fixit Glue', '100pc', 112, 121, 3, 'Fix it forever!', 'fi1.jpg', NULL),
(1215616, 'Everyuth facewash', '30pc', 145, 121, 4, 'Amazing combos with end of seasons price', 'ey1.png', '17%of'),
(1215619, 'Real Juice', '30pc', 149, 121, 4, 'My Real Fruit Power', 'real1.png', '25%off');

-- --------------------------------------------------------

--
-- Table structure for table `userdetails`
--

CREATE TABLE `userdetails` (
  `username` varchar(50) NOT NULL,
  `login_date` varchar(50) NOT NULL,
  `login_time` varchar(50) NOT NULL,
  `logout_date` varchar(50) NOT NULL,
  `logout_time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `email`, `password`) VALUES
('123', '12@12', '12345'),
('Aruna', 'aruna_vadagi@rediffm', 'xyz777'),
('markjonson', 'markjonson@gmail.com', 'markjonson12'),
('neharikasuresh', 'neharika@gmail.com', '123456'),
('rahulrai', 'rahulrai@gmail.com', '1234'),
('scarletgold', 'goldscarlet@gmail.co', 'scarle45t');

-- --------------------------------------------------------

--
-- Table structure for table `walmart`
--

CREATE TABLE `walmart` (
  `prod_ID` int(10) NOT NULL,
  `prod_name` varchar(50) NOT NULL,
  `stock` varchar(10) NOT NULL,
  `price` float NOT NULL,
  `shop_id` int(5) NOT NULL,
  `aisle_no` int(2) DEFAULT NULL,
  `describ` varchar(250) NOT NULL,
  `img` varchar(10000) NOT NULL,
  `offer` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `walmart`
--

INSERT INTO `walmart` (`prod_ID`, `prod_name`, `stock`, `price`, `shop_id`, `aisle_no`, `describ`, `img`, `offer`) VALUES
(1115600, 'Curtains', '10pc', 299, 111, 5, 'Beautiful drapes', 'download.jfif', '7%off'),
(1115601, 'Lizol floor cleaner', '7pc', 180, 111, 4, 'Healthing', 'liz2.jfif', '10%off'),
(1115602, 'Dove soap', '6pc', 35, 111, 4, 'Put your best face forward', 'd2.jfif', '5%off'),
(1115603, 'Comfort fabric freshner', '6pc', 149, 111, 4, 'Comfort makes a good clothes day', 'comf2.jfif', '20%off'),
(1115604, 'Apples', '15kg', 180, 111, 4, 'An apple a day, keeps medical expenses away!', 'ap1.jfif', '7%off'),
(1115605, 'Sugar', '50kg', 79, 111, 5, 'Sweet is never enough', 'sug2.jfif', '10%off'),
(1115606, '3 Roses Tea', '20pc', 55, 111, 4, 'The finest tea on earth', 'ro2.jfif', 'none'),
(1115607, '123 Masala Maggie', '40pc', 12, 111, 4, 'Taste of Magic', '2.jpg', '10%off'),
(1115608, 'Himalaya pure hands', '20pc', 55, 111, 5, 'kills 99.9% of germs', 'hp2.jfif', '10%off'),
(1115609, 'Dettol Hand Wash', '40pc', 249, 111, 5, 'Keep the memories, but not the bacteria', 'det2.jfif', '15%off'),
(1115610, 'Vicks Vapor Rub', '20pc', 79, 111, 5, 'Breathe Life In', 'vv2.jfif', 'none'),
(1115611, 'Huggies Diapers', '25pc', 15, 111, 5, ' There\'s nothing like a hug. What happens in Huggies stays in Huggies.', 'hug1.jfif', '20%off'),
(1115612, 'Papergrid Note Books', '100pc', 79, 111, 3, 'Unbeatable quality', 'pg2.jpg', NULL),
(1115613, 'Camel Water color', '50pc', 45, 111, 3, 'Har din colourful!', 'cw2.jpeg', NULL),
(1115614, 'Fevicol Glue', '45pc', 20, 111, 3, 'Fevicol ka mazboot jod hai Tootega nahi!', 'fc2.jpg', NULL),
(1115615, 'Fixit Glue', '100pc', 112, 111, 3, 'Fix it forever!', 'fi2.jpg', NULL),
(1115616, 'Everyuth Face Wash', '30pc', 145, 111, 4, 'Amazing combos with end of seasons price', 'ey2.jpg', '17%off'),
(1115617, 'Wattagirl Perfume', '40pc', 149, 111, 4, 'dil ki baat deal se', 'wg2.jpg', NULL),
(1115618, 'Essential Oils', '100pc', 199, 111, 4, 'Packed with the essentials', 'eo2.jpg', NULL),
(1115619, 'Real Juice', '30pc', 149, 111, 2, 'My Real Fruit Power', 'real2.jfif', '25%off');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `dmart`
--
ALTER TABLE `dmart`
  ADD PRIMARY KEY (`prod_ID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`prod_ID`);

--
-- Indexes for table `shoprite`
--
ALTER TABLE `shoprite`
  ADD PRIMARY KEY (`prod_ID`);

--
-- Indexes for table `shops`
--
ALTER TABLE `shops`
  ADD PRIMARY KEY (`shop_id`);

--
-- Indexes for table `starbazzar`
--
ALTER TABLE `starbazzar`
  ADD PRIMARY KEY (`prod_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `walmart`
--
ALTER TABLE `walmart`
  ADD PRIMARY KEY (`prod_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
